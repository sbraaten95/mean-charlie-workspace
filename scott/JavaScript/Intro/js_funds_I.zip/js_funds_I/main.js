function printArrVals(arr) {
	for (var i in arr) {
		console.log(arr[i]);
	}
}

function print500Sum() {
	sum = 0;
	for (var i = 1; i <= 500; i++) {
		sum += i;
	}
	console.log(sum);
}

function findMin(arr) {
	min = arr[0];
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] < min) {
			min = arr[i];
		}
	}
	console.log(min);
}

function findAvg(arr) {
	sum = 0;
	for (var i = 0; i < arr.length; i++) {
		sum += arr[i];
	}
	avg = sum/arr.length;
	console.log(avg)
}

var x = [3,5,'Dojo','rocks','Michael','Sensei'];

var new_ninja = {
	name: 'Jessica',
	profession: 'coder',
	favorite_language: 'JavaScript',
	dojo: 'Dallas'
}

printArrVals(x);
x.push(100)
x = ['hello', 'world', 'JavaScript is Fun']
console.log(x)
print500Sum()
findMin([1, 5, 90, 25, -3, 0])
findAvg([1, 5, 90, 25, -3, 0])

for (var key in new_ninja) {
	console.log(key, new_ninja[key])
}