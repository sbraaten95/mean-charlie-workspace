var domath = require('./mathlib')();

console.log(domath.add(2,3));
console.log(domath.multiply(2,3));
console.log(domath.square(3));
console.log(domath.ranNum(10,20));