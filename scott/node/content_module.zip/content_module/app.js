"use static";

var http = require('http');
var fs = require('fs');

