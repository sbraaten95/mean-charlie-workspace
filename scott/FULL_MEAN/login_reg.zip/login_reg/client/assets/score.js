function add(num, count) {
	return count + num;
}

var mom = 0;
var scott = 0;

mom = add(12, mom);
scott = add(17, scott);
mom = add(22, mom);
scott = add(16, scott);
mom = add(12, mom);
scott = add(34, scott);
mom = add(12, mom);
scott = add(18, scott);
mom = add(12, mom);
scott = add(28, scott);
mom = add(18, mom);
scott = add(18, scott);
mom = add(12, mom);
scott = add(21, scott);
mom = add(12, mom);
scott = add(26, scott);
mom = add(6, mom);
scott = add(26, scott);
mom = add(15, mom);
scott = add(11, scott);
mom = add(13, mom);
scott = add(17, scott);
mom = add(11, mom);
scott = add(2, scott);
mom = add(6, mom);
scott = add(11, scott);
mom = add(24, mom);
scott = add(8, scott);
mom = add(6, mom);
scott = add(10, scott);
mom = add(15, mom);
scott = add(10, scott);
mom = add(12, mom);
scott = add(17, scott);

console.log(mom, scott);